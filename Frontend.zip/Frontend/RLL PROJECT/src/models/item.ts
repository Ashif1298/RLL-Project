export class Item{
itemName:String='';
itemNumber:String='';
quantity:String='';
description:String='';
productId:String='';
unitPrice:String='';
totalPrice:String='';

}