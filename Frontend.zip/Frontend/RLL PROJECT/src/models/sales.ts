
export interface Sales{
itemName:String;
itemNumber:String;
quantity:String;
customerName:String;
customerId:String;
unityPrice:String;
totalStock:String;
saleId:String;
discount:String;
saleDate:String;

}
