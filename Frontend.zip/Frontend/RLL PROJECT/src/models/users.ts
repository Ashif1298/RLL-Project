export class Users{
name:String='';
password:String='';
user_name:String='';
    }