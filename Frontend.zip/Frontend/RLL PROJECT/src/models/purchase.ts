export interface Purchase{
itemName:String;
itemNumber:String;
quantity:String;
vendorName:String;
purchaseId:String;
unityPrice:String;
currentStock:String;
saleDate:String;
totalCost:String;

}
