import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/services/users.service';
import { Router } from '@angular/router';
import { RegUser } from '../models/RegistrationModel';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private userService: UserService, private router: Router, private fb: FormBuilder, private snackbar: MatSnackBar) { }
  registerForm !: FormGroup
  ngOnInit(): void {
    this.registerForm = this.fb.group({
      username: ['', Validators.required],
      pswd: ['', Validators.required],
      reEnterPswd: ['', Validators.required],
      name: ['', Validators.required]
    })
  }
  // register() {
  //   // console.log(this.name);
  //   const regUser = new RegUser();
  //   regUser.name = this.registerForm.value.name;
  //   regUser.password = this.registerForm.value.password;
  //   regUser.user_name = this.registerForm.value.username;

  //   this.userService.registerCustomer(regUser).subscribe((resp: any) => {
  //     alert(" Registered Successfully !!" + resp);  //   
  //   })

  // }

  reloadPage() {
    window.location.reload();
  }
  login() {
    this.router.navigate(['/login']);
  }
  register() {
// 
  if (this.registerForm.valid) {
    const regUser = new RegUser();
    regUser.name = this.registerForm.value.name;
    regUser.password = this.registerForm.value.pswd;
    regUser.user_name = this.registerForm.value.username;
    this.userService.registerCustomer(regUser).subscribe((resp: any) => {
      this.snackbar.open('Registered Successfully', 'close')
      this.router.navigate(['/login']);
    })
  } else {
    this.snackbar.open('Please Enter All Fields', 'close')
  }
  }

  clear() {
    this.registerForm.reset()
  }
}


// import { Component, OnInit } from '@angular/core';
// import { UserService } from 'src/services/users.service';
// import { Router } from '@angular/router';
// import { RegUser } from '../models/RegistrationModel';

// @Component({
//   selector: 'app-register',
//   templateUrl: './register.component.html',
//   styleUrls: ['./register.component.css']
// })
// export class RegisterComponent implements OnInit {

//   constructor(private userService: UserService,private router: Router) { }
//   name:string='';
//   username:string='';
//   password:string='';
//   confpassword:string='';
//   ngOnInit(): void {
//   }
//   reg()
//   {
//     console.log(this.name);
//     const regUser = new RegUser();
//     regUser.name = this.name;
//     regUser.password = this.password;
//     regUser.user_name = this.username;

//     this.userService.registerCustomer(regUser).subscribe((resp:any)=>{
//       alert(" Registered Successfully !!"+ resp);
//     })

//   }

//   reloadPage() {
//     window.location.reload();
//  }
//  login(){this.router.navigate(['/login']);
//  }
// }
