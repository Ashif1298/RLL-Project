export class Item{
    description:string='';
    itemName:string='';
    itemNumber:number=0;
    productId:number=0;
    quantity:number=0;
    totalPrice:number=0;
    unitPrice:number=0;
}