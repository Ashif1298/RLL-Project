export class RegUser{
    name:string='';
	user_name:string='';
	password:string='';
}