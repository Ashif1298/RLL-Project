import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { UserService } from 'src/services/users.service';

import { RegUser } from '../models/RegistrationModel';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm !: FormGroup;
  constructor(private snackbar: MatSnackBar, private userService: UserService, private router: Router, private fb: FormBuilder) { }
  // @Output('loggedInUser') loggedInuser = new EventEmitter();
  // username: string = '';
  // password: string = '';
  ngOnInit(): void {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      Password: ['', Validators.required]
    })

  }
  // login() {
  //   const regUser = new RegUser();
  //   regUser.username = this.username;
  //   regUser.password = this.password;
  //   regUser.name = this.username;
  //   this.userService.login(regUser).subscribe((resp: any) => {
  //     // alert('Login Sucessfully !!' +resp)
  //     this.userService.userBehavior.next(resp.username);
  //     localStorage.setItem('username', resp.username);
  //     this.router.navigate(['/']);
  //   }, error => {
  //     alert('Error while login !!' + error);
  //   })

  //   // this.snackbar.open('login Succefully','close')
  // }
  register() {
    this.router.navigate(['/register']);

  }

  userName: any;

  login() {
    console.log(this.loginForm.valid)
  

    if (this.loginForm.valid) {
      const regUser = new RegUser();
      regUser.user_name = this.loginForm.value.username;
      regUser.password = this.loginForm.value.Password;
      regUser.name = this.loginForm.value.username;
      this.userService.login(regUser).subscribe((resp: any) => {
        localStorage.setItem('username', this.loginForm.value.username);
        // localStorage.setItem('username',  resp.username);
        if (localStorage.getItem('username')) {
          this.userName = localStorage.getItem('username')
          this.router.navigate(['/welcome']);
        }
      }, err => {
        this.snackbar.open(err.error.message, 'close')

      })
    } else {
      this.snackbar.open('Please Enter Credentials', 'close')
    }
  }

}
