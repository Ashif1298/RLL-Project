import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {
  userName: any;
  constructor() { }

  ngOnInit(): void {
    if (localStorage.getItem('username')) {
      this.userName = localStorage.getItem('username')
      // this.router.navigate(['/welcome']);
    }
  }

}