import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  @Input() userExist: any;
  userName: any;
  constructor(private router: Router) { }

  ngOnInit(): void {
    if (localStorage.getItem('username')) {
      this.userName = localStorage.getItem('username')
      console.log(this.userName)
    }
    // this.userName = this.userExist
    console.log(this.userName)
  }

  logout() {
    localStorage.clear()
    this.userExist = undefined
    this.router.navigate(['']);
  }

}
